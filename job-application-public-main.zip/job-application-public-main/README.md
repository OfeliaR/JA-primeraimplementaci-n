# Job Application

Recursos para el proyecto Job Application abiertos a personas externas:

- [Guía con aspectos generales del proyecto y mentorías](./00-context/README.md)
- [Evaluaciones y feedback RH](./01-hr-mentoring/interviewer-guide/README.md)
- [Evaluaciones y feedback Tech](./02-tech-mentoring/interviewer-guide/README.md)
