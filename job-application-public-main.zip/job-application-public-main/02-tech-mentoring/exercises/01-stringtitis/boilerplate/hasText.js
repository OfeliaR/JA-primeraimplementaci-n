const hasText = (a, b) => {
  // ...
};

module.exports = hasText;