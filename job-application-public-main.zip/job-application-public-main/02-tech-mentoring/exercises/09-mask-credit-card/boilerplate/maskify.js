const maskify = (str) => {
  // ...
};

module.exports = maskify;
