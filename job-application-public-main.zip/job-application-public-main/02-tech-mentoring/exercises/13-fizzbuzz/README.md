# FizzBuzz

Implementa una función que imprima los números de `1` a `n`, pero para los
múltiplos de `3` imprime `fizz` en vez del número, y para los múltiplos de `5`
imprime `buzz`. Para números que sean múltiplos de ambos (`3` y `5`) debe
imprimir `fizzbuzz`.

[FizzBuzz: Una Pregunta de Entrevistas Simple - Computerphile en YouTube](https://www.youtube.com/watch?v=QPZ0pIK_wsc)

## Ejemplo

```js
fizzBuzz(5);
// -> 1
// -> 2
// -> fizz
// -> 4
// -> buzz
```
