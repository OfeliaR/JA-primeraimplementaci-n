# Capitalize

Implementa una función que acepte un `String`, ponga la primera letra de cada
palabra en mayúscula y que retorne un nuevo `String` con el resultado.

## Ejemplos

```js
capitalize('a short sentence') // --> 'A Short Sentence'
capitalize('a lazy fox') // --> 'A Lazy Fox'
capitalize('look, it is working!') // --> 'Look, It Is Working!'
```
