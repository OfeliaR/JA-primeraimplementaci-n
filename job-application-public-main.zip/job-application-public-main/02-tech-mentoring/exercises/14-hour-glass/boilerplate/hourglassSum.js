const hourglassSum = (arr) => {
  // ...
};

module.exports = hourglassSum;