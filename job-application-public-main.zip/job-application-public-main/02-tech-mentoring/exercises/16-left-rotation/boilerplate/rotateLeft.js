const rotateLeft = (d, arr) => {
  // ...
};

module.exports = rotateLeft;