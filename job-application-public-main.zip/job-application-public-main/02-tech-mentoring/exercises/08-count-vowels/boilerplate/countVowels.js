const countVowels = (str) => {
  // ...
};

module.exports = countVowels;