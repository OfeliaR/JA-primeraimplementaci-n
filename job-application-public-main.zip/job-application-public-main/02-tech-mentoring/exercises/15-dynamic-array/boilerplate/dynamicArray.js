const dynamicArray = (n, queries) => {
  // ...
};

module.exports = dynamicArray;