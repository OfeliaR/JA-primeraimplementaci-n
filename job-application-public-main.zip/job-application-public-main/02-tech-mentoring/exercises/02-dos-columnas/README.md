# Dos columnas

- Crea una interfaz web de dos columnas usando HTML y CSS.
- Haz que el diseño sea fluido, de modo que los tamaños relativos de las
  columnas se mantengan cuando se cambie el tamaño de la ventana.
- Establece un ancho mínimo y máximo para las columnas.
- Asegúrate de que ambas columnas tengan siempre la misma altura.
- En pantallas pequeñas, convierte el diseño en una sola columna.
