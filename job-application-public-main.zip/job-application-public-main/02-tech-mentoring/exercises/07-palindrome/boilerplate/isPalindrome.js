const isPalindrome = (str) => {
  // ...
};

module.exports = isPalindrome;