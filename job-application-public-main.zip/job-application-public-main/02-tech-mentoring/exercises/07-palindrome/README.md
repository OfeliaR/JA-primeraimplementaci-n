# Palíndromo

Crea una función que identifique si un string es un palíndromo (esto es, se lee
igual al derecho o al revés), retornando _true_ si lo es o _false_ si no.

````js
isPalindrome('ana') // returns true
isPalindrome('holo') // returns false
isPalindrome('neveroddoreven') // returns true
isPalindrome('stresseddesserts') // returns true
````
