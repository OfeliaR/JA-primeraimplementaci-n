const analyseArray = (arr) => {
  // ...
};

module.exports = analyseArray;